<?php
return [
  'storage_path' => env('STORAGE_PATH','http://127.0.0.1:8000'),
  'default_image' => env('STORAGE_PATH','http://127.0.0.1:8000').'defualt_image.png',
  'storage_type' => env('STORAGE_TYPE','public'),
];
?>