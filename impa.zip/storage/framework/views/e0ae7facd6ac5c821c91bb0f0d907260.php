<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/vendor-js/owl-carousel/css/owl.carousel.min.css')); ?> ">
    <link rel="stylesheet" href="<?php echo e(asset('/vendor-js/owl-carousel/css/owl.theme.default.min.css')); ?> ">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Datatable -->
    <link href="<?php echo e(asset('vendor-js/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('vendor-js/toastr/css/toastr.min.css')); ?>">
    <link href="<?php echo e(asset('/vendor-js/jqvmap/css/jqvmap.min.css')); ?> " rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>
<body>
  
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="index.html" class="brand-logo">
                <img class="logo-abbr" src="<?php echo e(asset('images/logo.png')); ?>" alt="">
                <img class="logo-compact" src="<?php echo e(asset('images/logo-text.png')); ?>" alt="">
                <img class="brand-title" src="<?php echo e(asset('images/logo-text.png')); ?>" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">

                        <div class="header-left">

                            <!-- <div class="search_bar dropdown">
                                <span class="search_icon p-3 c-pointer" data-toggle="dropdown">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                                <div class="dropdown-menu p-0 m-0">
                                    <form>
                                        <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                                    </form>
                                </div>
                            </div>
                             -->
                        </div>

                        <ul class="navbar-nav header-right">
                            <li class="nav-item dropdown notification_dropdown">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <i class="mdi mdi-bell"></i>
                                    <div class="pulse-css"></div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <ul class="list-unstyled">
                                        <li class="media dropdown-item">
                                            <span class="success"><i class="ti-user"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong>Martin</strong> has added a <strong>customer</strong>
                                                        Successfully
                                                    </p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="primary"><i class="ti-shopping-cart"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong>Jennifer</strong> purchased Light Dashboard 2.0.</p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="danger"><i class="ti-bookmark"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong>Robin</strong> marked a <strong>ticket</strong> as
                                                        unsolved.
                                                    </p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="primary"><i class="ti-heart"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong>David</strong> purchased Light Dashboard 1.0.</p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="success"><i class="ti-image"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <p><strong> James.</strong> has added a<strong>customer</strong>
                                                        Successfully
                                                    </p>
                                                </a>
                                            </div>
                                            <span class="notify-time">3:20 am</span>
                                        </li>
                                    </ul>
                                    <a class="all-notification" href="#">See all notifications <i
                                            class="ti-arrow-right"></i></a>
                                </div>
                            </li>
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <i class="mdi mdi-account"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="./app-profile.html" class="dropdown-item">
                                        <i class="icon-user"></i>
                                        <span class="ml-2">Profile </span>
                                    </a>
                                    <a href="./email-inbox.html" class="dropdown-item">
                                        <i class="icon-envelope-open"></i>
                                        <span class="ml-2">Inbox </span>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                       <?php echo csrf_field(); ?>
                                           <button type="submit" href="./page-login.html" class="dropdown-item">
                                              <i class="icon-key"></i>
                                              <span class="ml-2">Logout </span>
                                          </button>
                                    </form>
                                
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="quixnav">
            <div class="quixnav-scroll">
                <ul class="metismenu" id="menu">
                    <li class="nav-label first">Main Menu</li>
                    <li>
                        <a  href="<?php echo e(route('home')); ?>" aria-expanded="false">
                            <i class="fa-solid fa-gauge"></i>
                            <span class="nav-text">Dashboard</span></a>
                    </li>
                    
                    <?php if(isAdmin()): ?>
                     <li>
                        <a  href="<?php echo e(route('user.index')); ?>" aria-expanded="false">
                            <i class="icon icon-single-04"></i>
                            <span class="nav-text">User</span>
                        </a>
                    </li>
                    
                    <li>
                        <a  href="<?php echo e(route('service.index')); ?>" aria-expanded="false">
                            <i class="fa-solid fa-globe"></i>
                            <span class="nav-text">Service </span>
                        </a>
                    </li>
                    
                    
                    <li>
                        <a  href="<?php echo e(route('brand.index')); ?>" aria-expanded="false">
                           <i class="fa-solid fa-hand-holding-medical"></i>
                            <span class="nav-text">Brands & Emergency </span>
                        </a>
                    </li>
                
                    
                     <li>
                        <a  href="<?php echo e(route('brand-category.index')); ?>" aria-expanded="false">
                            <i class="fa fa-list-alt" aria-hidden="true"></i>
                            <span class="nav-text">Brand Category </span>
                        </a>
                    </li>
                    
                    <li>
                        <a  href="<?php echo e(route('part.index')); ?>" aria-expanded="false">
                           <i class="fa fa-cogs" aria-hidden="true"></i>
                            <span class="nav-text">Part </span>
                        </a>
                    </li>
                    
                    
                    <li>
                        <a  href="<?php echo e(route('car-type.index')); ?>" aria-expanded="false">
                            <i class="fa-solid fa-car"></i>
                            <span class="nav-text">Car Types  </span>
                        </a>
                    </li>
                    
                    <li>
                        <a  href="<?php echo e(route('engine-type.index')); ?>" aria-expanded="false">
                            <i class="fa-solid fa-dumbbell"></i>
                            <span class="nav-text">Engine Types</span>
                        </a>
                    </li>
                    
                    <li>
                        <a  href="<?php echo e(route('user-car.index')); ?>" aria-expanded="false">
                            <i class="fa-solid fa-address-card"></i>
                            <span class="nav-text">User Car </span>
                        </a>
                    </li>
                    
                    <li>
                        <a  href="<?php echo e(route('invoice.index')); ?>" aria-expanded="false">
                            <i class="fa-solid fa-receipt"></i>
                            <span class="nav-text">Invoice</span>
                        </a>
                    </li>
                    <li>
                        <a  href="<?php echo e(route('quotation.index')); ?>" aria-expanded="false">
                            <i class="fa-solid fa-quote-right"></i>
                            <span class="nav-text">Quotation</span>
                        </a>
                    </li>
                    
                    <?php endif; ?>
                    
                    

                    <!-- <li>
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                            <i class="icon icon-single-04"></i><span class="nav-text">Dashboard</span></a>
                        <ul aria-expanded="false">
                            <li><a href="./index.html">Users</a></li>
                            <li><a href="./index2.html">Dashboard 2</a></li>
                        </ul>
                    </li>
                     -->
                <!--     <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                    class="icon icon-chart-bar-33"></i><span class="nav-text">Charts</span></a>
                                <ul aria-expanded="false">
                <li><a href="./chart-flot.html">Flot</a></li>
                <li><a href="./chart-morris.html">Morris</a></li>
                <li><a href="./chart-chartjs.html">Chartjs</a></li>
                <li><a href="./chart-chartist.html">Chartist</a></li>
                <li><a href="./chart-sparkline.html">Sparkline</a></li>
                <li><a href="./chart-peity.html">Peity</a></li>
                                </ul>
                            </li> -->
            

                </ul>
            </div>


        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
              
              <?php if($errors->any()): ?>
    <div class="error-summary">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="text-danger"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

               <?php echo $__env->yieldContent('content'); ?>


            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Quixkit</a> 2019</p>
                <p>Distributed by <a href="https://themewagon.com/" target="_blank">Themewagon</a></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    
    
        <!-- Required vendors -->
    <script src="<?php echo e(asset('/vendor-js/global/global.min.js' )); ?> "></script>
    <script src="<?php echo e(asset('/js/quixnav-init.js' )); ?> "></script>
    <script src="<?php echo e(asset('/js/custom.min.js' )); ?> "></script>


    <!-- Vectormap -->
    <script src="<?php echo e(asset('/vendor-js/raphael/raphael.min.js' )); ?> "></script>
    <script src="<?php echo e(asset('/vendor-js/morris/morris.min.js' )); ?> "></script>


    <script src="<?php echo e(asset('/vendor-js/circle-progress/circle-progress.min.js' )); ?> "></script>

    <!--  flot-chart js -->
    <script src="<?php echo e(asset('/vendor-js/flot/jquery.flot.js' )); ?> "></script>
    <script src="<?php echo e(asset('/vendor-js/flot/jquery.flot.resize.js' )); ?> "></script>

    <!-- Owl Carousel -->
    <script src="<?php echo e(asset('/vendor-js/owl-carousel/js/owl.carousel.min.js' )); ?> "></script>

    <!-- Counter Up -->
    <script src="<?php echo e(asset('/vendor-js/jqvmap/js/jquery.vmap.min.js' )); ?> "></script>
    <script src="<?php echo e(asset('/vendor-js/jqvmap/js/jquery.vmap.usa.js' )); ?> "></script>
    <script src="<?php echo e(asset('/vendor-js/jquery.counterup/jquery.counterup.min.js' )); ?> "></script>

    <script src="<?php echo e(asset('/js/dashboard/dashboard-1.js' )); ?> "></script>
    
    <!-- Datatable -->
    <script src="<?php echo e(asset('vendor-js/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins-init/datatables.init.js')); ?>"></script>
    
    <!-- Toastr -->
    <script src="<?php echo e(asset('vendor-js/toastr/js/toastr.min.js')); ?>"></script>

    <!-- All init script -->
<!--     <script src="<?php echo e(asset('js/plugins-init/toastr-init.js')); ?>"></script> -->

<?php echo $__env->yieldPushContent('js'); ?>

<script>
  let tosterOption = {
                    positionClass: "toast-top-right",
                    timeOut: 5e3,
                    closeButton: !0,
                    debug: !1,
                    newestOnTop: !0,
                    progressBar: !0,
                    preventDuplicates: !0,
                    onclick: null,
                    showDuration: "300",
                    hideDuration: "1000",
                    extendedTimeOut: "1000",
                    showEasing: "swing",
                    hideEasing: "linear",
                    showMethod: "fadeIn",
                    hideMethod: "fadeOut",
                    tapToDismiss: !1
                };
</script>

<?php if(session()->has('success')): ?>
  <script>
      toastr.success("Success",'<?php echo e(session()->get("success")); ?>' , tosterOption);
  </script>
<?php endif; ?>

<?php if( session()->has('info') ): ?>
<script>
  toastr.info("Info",'<?php echo e(session()->get("info")); ?>' , tosterOption);
</script>
<?php endif; ?>

<?php if( session()->has('error') ): ?>
<script>
  toastr.success("Error",'<?php echo e(session()->get("error")); ?>' , tosterOption);
</script>
<?php endif; ?>

<?php if( session()->has('warning') ): ?>
<script>
  toastr.warning("Warning",'<?php echo e(session()->get("warning")); ?>' , tosterOption);
</script>
<?php endif; ?>

</body>
</html>
<?php /**PATH /data/data/com.termux/files/home/imap/resources/views/layouts/app.blade.php ENDPATH**/ ?>