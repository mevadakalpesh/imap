<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
      font-family: DejaVu Sans, serif;
    }

    .rtl {
      width: 100%;
      text-align: center;
      direction: rtl;
    }

    .address strong {
      display: block;
      font-size: 16px;
    }

    .header {
      max-height: 250px;
      display: flex;
    }


    .header .logo img {
      width: 150px;
      height: auto;
      position: relative;
      padding: 0px 15px;
    }

    .title-div {
      margin: 0px;
      width: 100%;
      height: auto;
      text-align: center;
    }


    .main {
      padding-top: 10px;
      width: 100%;
    }

    .table-1 table,
    .table-1 th,
    .table-1 td {
      border: 1px solid black;
      border-collapse: collapse;
    }

    .table-1 table {
      text-align: center;
      width: 100%;
      font-weight: bold;
    }

    .teble-6 {
      width: 100%;
      font-weight: bold;
      border: none;
    }

    .teble-6 tr,
    td,
    img {
      padding: 0px 10px;
    }

    .teble-6 {
      width: 100%;
    }
    .teble-7 table {
      width: 100%;

    }

    .Conditions {
      width: 100%;
      align-items: center;
    }

    .total-sub {
      width: 100%;
    }

    .total-sub table,
    .total-sub tr,
    .total-sub td,
    .total-sub h4 {
      text-align: end;
      width: 100%;
      font-weight: bold;
    }

    .Conditions table,
    .Conditions tr,
    .Conditions td,
    .Conditions h4 {

      text-align: center;
    }
    .Delivery .acceptable {
      font-size: 15px;
    }
    .Delivery .intrest {
      margin-top: 40px;
    }
    .Fix {
      text-align: center;
      font-weight: bold;
    }



  </style>
</head>

<body>
  <div class="table-6">
    <table width="100%">
      <tr>
        <td><strong>Phone: +97477000451</strong></td>a
        <td rowspan="5"><img width="100px" src="{{ public_path('/images/craop.jpg') }}" alt=""></td>
        <td><strong>+97477000451 جوال </strong></td>
      </tr>
      <tr>
        <td> <strong>AlDoha - Area 26</strong></td>
        <td> <strong>26 الدوحة - منطقة</strong></td>
      </tr>
      <tr>
        <td> <strong>Str 940 - Najma</strong></td>
        <td> <strong>شارع 940 - النجمة</strong></td>
      </tr>
      <tr>
        <td><strong>Office 201</strong></td>
        <td><strong>مكتب 201</strong></td>
      </tr>

    </table>
  </div>

  <div class="main">
    <div class="title-div">
      <h2 class="rtl">كليك اند فيكس للسيـــارات</h2>
      <h2 class="rtl">Click and Fix</h2>
      <h2>Quotation</h2>
    </div>
  </div>
  <div class="table-1">
    <table width="100%">
      <tr>
        <td rowspan="2">TO</td>
        <td rowspan="2">{{ $quotation->quotation_to ?? "-" }}</td>
        <td>Ref No</td>
        <td>Date تاريخ </td>
      </tr>
      <tr>
        <td>{{ $quotation->ref_no ?? "-" }}</td>
        <td>{{ $quotation->quotation_date ?? "-" }}</td>
      </tr>
      <tr>
        <td>Attn</td>
        <td>{{ $quotation->quotation_attn ?? "-" }}</td>
        <td>From</td>
        <td>{{ $quotation->quotation_from ?? "-" }}</td>
      </tr>
      <tr>
        <td>Title</td>
        <td>{{ $quotation->quotation_title ?? "-" }} </td>
        <td>Fax </td>
      </tr>
      <tr>
        <td>Your Ref</td>
        <td>{{ $quotation->your_ref ?? "-" }}</td>
        <td>Subject</td>
        <td>{{ $quotation->subject ?? "-" }}</td>
      </tr>
    </table>
  </div>
  <div class="dear-sir">
    <h4>Dear Sir</h4>
    <p>
      We have a pleasure in submitting our offer for you as follows
    </p>
  </div>
  <div class="table-1">
    <table width="100%">
      <tr>
        <td>الرقم<br> Sl No.</td>
        <td>التفاصيل<br>DISCRIPTION</td>
        <td>الوحدة<br>unit</td>
        <td>الكمية<br>Qty</td>
        <td class="teb-td">سعر الوحدة <br>Unit PriceQrs.</td>
        <td class="teb-td">المبلغ<br>Amount Qrs.</td>
      </tr>
  <?php  if( isset($quotation->fields) && !empty($quotation->fields) ){
                  $i = 1;
                  foreach ($quotation->fields as $field){
                ?>
                <tr>
                    <td>{{ $i }}</td>
                    <td>{{ $field->description ?? "-" }}</td>
                    <td>{{ $field->unit ?? "-" }}</td>
                    <td>{{ $field->qty ?? "-" }}</td>
                    <td>{{ $field->unit_price ?? "-" }}</td>
                    <td>{{ $field->amount ?? "-" }}</td>
                </tr>
                <?php  $i++; 
                } 
                } ?>

    </table>
  </div>
  <div class="total-sub">
    <table width="100%">
      <tr>
        <td>
          <p>
            Sub Total
          </p>
          <p>
            Total QAR
          </p>
        </td>
        <td>
          <p>
            1200
          </p>
          <p>
            Thousand and two
          </p>
          <p>
            hundred QAR
          </p>
        </td>
      </tr>
    </table>
  </div>

  <div class="Conditions">
    <table width="100%">
      <tr>
        <td>
          <h4>validity</h4>
        </td>
        <td>
          <h4>Upon Request</h4>
        </td>
        <td>
          <h4>Terms & Conditions</h4>
        </td>
      </tr>
    </table>
  </div>
  <div class="Delivery">
    <table width="100%">
      <tr>
        <td width="80%">
          <h3>Delivery</h3>
          <p class="acceptable">
            Hope our rates are acceptable to you and awaiting your valued order. Please feel to contact us
            on +97477000451 for
            any information of your intrest
          </p>
        </td>
        <td width="20%">
          <img class="intrest" width="100%" src="{{ public_path('/images/bottomlogo.jpg') }}" alt="">
        </td>
      </tr>
    </table>
  </div>

  <h2> Terms And Conditions</h2>
  <p>
    All quotations and references to costs and financial commitments made or made by the
    seller are based on the assumption that the correctness of the information provided to be
    absolutely accurate and true in all circumstances. Seller reserves the right at any stage to
    renegotiate any contract, cost agreement or other related obligation in the event if any
    information provided by the Buyer fails to be completely true and accurate. offer Valid for 48
    hours from the date of order .
  </p>
  <div>

  </div>
</body>

</html>