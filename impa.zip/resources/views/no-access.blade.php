@extends('layouts.app')

@section('content')

<div class="row page-titles mx-0">
  <div class="col-sm-6 p-md-0">
    <div class="welcome-text">
      <h4>Hi, You Dont Have Access This Page Please Contact The Admin</h4>
    </div>
  </div>

</div>

@endsection